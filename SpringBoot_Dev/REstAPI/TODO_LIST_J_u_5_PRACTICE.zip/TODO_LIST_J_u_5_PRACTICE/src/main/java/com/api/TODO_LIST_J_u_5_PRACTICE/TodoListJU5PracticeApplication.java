package com.api.TODO_LIST_J_u_5_PRACTICE;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TodoListJU5PracticeApplication {

	public static void main(String[] args) {
		SpringApplication.run(TodoListJU5PracticeApplication.class, args);
	}

}
